export const proxy = 'https://cors-anywhere.herokuapp.com/';
export const key = 'b49aad4e56d50b14a0069e70d8dc24f5';